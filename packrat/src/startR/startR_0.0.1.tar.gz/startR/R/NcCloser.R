NcCloser <- function(file_object) {
  easyNCDF::NcClose(file_object)
}
