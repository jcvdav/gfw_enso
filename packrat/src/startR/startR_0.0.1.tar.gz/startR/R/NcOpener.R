NcOpener <- function(file_path) {
  easyNCDF::NcOpen(file_path)
}
