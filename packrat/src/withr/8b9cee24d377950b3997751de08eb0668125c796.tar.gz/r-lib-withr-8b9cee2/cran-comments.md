## Test environments
* OS X El Capitan, R 3.4.3
* ubuntu 12.04 (on travis-ci), R 3.4.3, 3.3.3, 3.2.5, 3.1, R-devel
* Windows Server 2012 R2 (x64), R 3.4.3
* Rhub

## R CMD check results
There were no NOTEs, ERRORs or WARNINGs.

## Downstream dependencies
* I ran R CMD check on all 50 downstream dependencies of withr; there were not
  related issues from this release.
  Summary at: https://github.com/r-lib/withr/tree/master/revdep#readme
