library(testthat)
library(commarobust)

test_check("commarobust")
